// pages/adminOutReader/adminOutReader.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userid: null,
    flag: null,
    userinfo: null,
    inputflag: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  getInput: function (input) {
    var that = this
    console.log(input)
    this.setData({
      userid: input.detail.value
    })
    wx.request({
      url: 'http://localhost:8080/Kcsj_3/wxAdminAlterReaderServlet1?userid=' + this.data.userid,
      success: function (res) {
        console.log(res.data)
        that.setData({
          userinfo: res.data
        })
        console.log(res.data.flag)
        if (res.data.flag) {
          wx.showToast({
            title: '请修改',
          })
          that.setData({
            inputflag: false
          })
        } else {
          wx.showToast({
            title: 'ID不存在',
          })

        }
      }
    })
  },
  goAlterReader: function (e) {
    var that = this;
    this.setData({
      bookinfo: e.detail.value
    })
    wx.request({
      url: 'http://localhost:8080/Kcsj_3/wxAdminAlterReaderServlet2?userid=' + e.detail.value.userid + "&&username=" + e.detail.value.username + "&&departments=" + e.detail.value.departments + "&&major=" + e.detail.value.major + "&&phone=" + e.detail.value.phone + "&&email=" + e.detail.value.email + "&&max=" + e.detail.value.max + "&&time=" + e.detail.value.time ,
      success: function (res) {
        console.log(res.data)
        that.setData({
          flag: res.data
        })
        console.log(that.data.flag)
        if (that.data.flag) {
          wx.showToast({
            title: '修改成功',
          })
        } else {
          wx.showToast({
            title: '修改失败',
          })
        }

      }
    })
  }
})