// pages/adminAddReader/adminAddReader.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    flag:null
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },
  goAddReader:function(e){
    console.log(e.detail.value)
    var that = this
    wx.request({
      url: 'http://localhost:8080/Kcsj_3/wxAdminAddReaderServlet?username=' + e.detail.value.username + "&&departments=" + e.detail.value.departments + "&&major=" + e.detail.value.major + "&&phone=" + e.detail.value.phone + "&&email=" + e.detail.value.email + "&&max=" + e.detail.value.max + "&&time=" + e.detail.value.time,
      success: function (res) {
        console.log(res.data)
        that.setData({
          flag: res.data
        })
        console.log(that.data.flag)
        if (that.data.flag) {
          wx.showToast({
            title: '添加成功',
          })
        } else {
          wx.showToast({
            title: '添加失败',
          })
        }
      }

    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})